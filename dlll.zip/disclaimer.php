<?php
/*******************************************************************
* Glype is copyright and trademark 2007-2013 UpsideOut, Inc. d/b/a Glype
* and/or its licensors, successors and assigners. All rights reserved.
*
* Use of Glype is subject to the terms of the Software License Agreement.
* http://www.glype.com/license.php
*******************************************************************
*
* BY USING THIS DISCLAIMER, YOU ACKNOWLEDGE AND AGREE THAT ALL INFORMATION
* CONTAINED HEREIN DOES NOT CONSTITUTE LEGAL ADVICE OF ANY KIND OR NATURE.
* PLEASE CONSULT WITH LEGAL COUNSEL BEFORE USING THIS DISCLAIMER.
*
/*****************************************************************
* Initialize glype
******************************************************************/

require 'includes/init.php';


/*****************************************************************
* Create content
******************************************************************/

$content = <<<OUT
	<h2 class="first">免责声明</h2>
　　<p>提供此服务,没有任何形式的保证。使用这个服务是完全在你的自己的风险。我们不能承担任何直接或间接损害造成使用这项服务。</p>
　　<p>服务允许间接浏览外部的第三方网站。我们不负责任何外部网站的内容,可以通过我们的服务。一个网站从我们的服务不属于或与本网站有关。</p>
　　<p>浏览“间接”这一术语指的是你连接到的服务器。在“直接”浏览,您连接到服务器提供的资源请求。在“间接”浏览,你连接到我们的服务器。我们的脚本下载请求的资源,并将其转发给你。</p>
　　<p>任何资源(如web页面、图像文件)下载通过我们的服务可能被修改。这可能包括,但不限于,编辑目标资源引用的url,这样任何资源也间接地下载。这个过程的准确性和可靠性是没有保证的。资源,你得到的可能不是一个精确的表示资源请求。</p>
　　<p>间接匿名浏览可能的副作用。通过连接到我们的服务器而不是目标服务器,目标服务器不看到你的IP地址。然而,我们不能保证我们的服务将会真正的匿名。下载的资源可能引用其他资源浏览器会自动下载。服务试图将所有这样的请求通过我们的服务器但可能不是完全成功。一个直接请求将损害你的匿名。</p>
　　<p>这个服务可能下载资源在一个安全的连接,但这可能是发送回你一个未加密的连接。不要进入机密信息,除非你在一个安全的连接到我们的服务器。</p>
OUT;


/*****************************************************************
* Send content wrapped in our theme
******************************************************************/

echo replaceContent($content);
