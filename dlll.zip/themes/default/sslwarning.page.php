<html>
<head>
	<title>Security Warning</title>
	<style type="text/css">
html, body {
	background: #0b1933;
	text-align: center;
}
body {
	font: 80% Tahoma;
}
#wrapper {
	margin: 100px auto;
	width: 500px;
	text-align: left;
	background: #fff;
	padding: 10px;
   border: 5px solid #ccc;
}
form { 
   text-align: center;
}
	</style>
   <base href="<?php echo GLYPE_URL; ?>/">
</head>
<body>
	<div id="wrapper">
		<h1>警告!</h1>
		<p> 您正试图浏览的网站是一个安全连接，但代理不是安全连接，继续访问可能存在风险。</ p>　　
      <form action="includes/process.php" method="get">
         <input type="hidden" name="action" value="sslagree">
			<input type="submit" value="继续访问...">
         <input type="button" value="返回首页" onclick="window.location='.';">
		</form>
      <p><b>注:</b> 该提示将不再出现.</p>
	</div>
</body>
</html>